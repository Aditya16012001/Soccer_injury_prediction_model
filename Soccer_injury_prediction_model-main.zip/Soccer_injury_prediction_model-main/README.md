# Soccer_injury_prediction_model
Machine learning project predicting major injuries in English Premier League players using SVM, Random Forest, KNN, and XGBoost. Features include data preparation, feature engineering, model training, evaluation metrics, and performance analysis to enhance injury risk management.
